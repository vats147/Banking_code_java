﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        string dtp;
        string gender;
        int si;
        string hobbies;
        Form2 f2 = new Form2();
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-5DLUIKK\SQLEXPRESS;Initial Catalog=076;Integrated Security=True");
        public Form1()
        {
            InitializeComponent();
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            f2.Show();
           // this.Close();
            this.Hide();
            //this.Close()
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            con.Close();
            con.Open();
            string dtp =Convert.ToString(dateTimePicker1.Value.ToString("yyyy-MM-dd"));
            string gender="";
            if (radioButton1.Checked)
            {
                gender = "Male";
            }
            else if (radioButton2.Checked)
            {
                gender = "Female";
            }

            string hobbies = "";
            string sep = ",";
            if (checkBox1.Checked)
            {
                hobbies = "Traveling"+ sep;
            }
            if (checkBox2.Checked)
            {
                hobbies += "Writing" + sep;
            }
            if (checkBox3.Checked)
            {
                hobbies += "Singing" + sep;
            }
            if (checkBox4.Checked)
            {
                hobbies += "Suffering " + sep;
            }


          //  MessageBox.Show(maskedTextBox1.Text);
            int si =Convert.ToInt32(comboBox1.SelectedValue);
            //SqlCommand cmd= new
            SqlCommand cmd = new SqlCommand("insert into table_x values('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + dtp + "','" + gender + "','" + hobbies + "','" + si + "','" + maskedTextBox1.Text + "');", con);

            MessageBox.Show("Inseerted succesfully");
            cmd.ExecuteNonQuery();
            con.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("select * from City", con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);

            DataTable dt = new DataTable();
            sda.Fill(dt);

            comboBox1.DataSource = dt;

            comboBox1.ValueMember = "id";
            comboBox1.DisplayMember = "city";

            //dr = dt.NewRow(); 
            
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            con.Close();
            con.Open();




            string dtp = Convert.ToString(dateTimePicker1.Value.ToString("yyyy-MM-dd"));
            string gender = "";
            if (radioButton1.Checked)
            {
                gender = "Male";
            }
            else if (radioButton2.Checked)
            {
                gender = "Female";
            }

            string hobbies = "";
            string sep = ",";
            if (checkBox1.Checked)
            {
                hobbies = "Traveling" + sep;
            }
            if (checkBox2.Checked)
            {
                hobbies += "Writing" + sep;
            }
            if (checkBox3.Checked)
            {
                hobbies += "Singing" + sep;
            }
            if (checkBox4.Checked)
            {
                hobbies += "Suffering " + sep;
            }


            //  MessageBox.Show(maskedTextBox1.Text);
            int si = Convert.ToInt32(comboBox1.SelectedValue);
            //SqlCommand cmd= new


            SqlCommand cmd=new SqlCommand("update table_x set name='"+textBox2.Text+"',address='"+textBox3.Text+"',date='"+dtp+"',gender='"+gender+"',hobbies='"+hobbies+"',city='"+si+"',password='"+maskedTextBox1.Text+"' where id='"+textBox1.Text+"';",con);
            cmd.ExecuteReader();
            MessageBox.Show("updated succesfully");
            con.Close();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            con.Close();
            con.Open();
            SqlCommand cmd = new SqlCommand("delete from table_x where id=" + textBox1.Text + ";", con);
            cmd.ExecuteReader();
            MessageBox.Show("Deleted");
            con.Close();
        }
    }
}
