#include<iostream>
using namespace std;

class customer{
    string Customer_Name;
    long Account_No;
    short pin;
    string Customer_Mail;
    string Account_type;

    public:
    customer(){Customer_Name="hello";Account_No=541;}
    void Print_Customer_Detail(){
        cout<<"Customer name "<<Customer_Name<<endl;
        cout<<"Account number  "<<Account_No;
        
    }
};

int main(){
        customer cu;
        cu.Print_Customer_Detail();



}