import java.util.*;
import java.lang.*;import java.io.*;
//class for bank
//

//class for new customer of bank 
public class customer{
   
    String Customer_Name;
    long Account_no;
    Short pin;
    String Customer_Mail;
    String Account_type;
    customer(){
        Account_no=1231;
    }
    // customer(String Customer_Name,long Account_no,Short pin,String Customer_Mail,String Account_type)
    // {
    //     this.Customer_Name=Customer_Name;
    //     this.Account_no=Account_no;
    //     this.pin=pin;
    //     this.Customer_Mail=Customer_Mail;
    //     this.Account_type=Account_type;
    // }

    public  void Print_customer_detail(){
        System.out.println("Account holder name : " + Customer_Name);
        System.out.println("Account number  : " + Account_no);
        System.out.println("Account pin  : " + pin);
        System.out.println("Your mail is  : " + Customer_Mail);
        System.out.println("Account type is : " + Account_type);


    }

}

//class for main fuctions
class temp {
    public static void Print_Bank_Name() {
        System.out.println("welcome to BOB bank");
    }

    public static void Print_Choice() {
        System.out.println("Please give choice");
    }

    public static void Divider() {
        System.out.println("**********************");
    }

    public static void main(String args[]) {

        Print_Bank_Name();
        Scanner sc = new Scanner(System.in);
        int Choice_1, Choice_2, Choice_3,Choice_4=0;

        do {
            System.out.println(" 1. Login");
            System.out.println(" 2. Register");
            System.out.println(" 3. Deposite Money");
            System.out.println(" 4. Create an account");
            System.out.println(" 5. Exit");
            Print_Choice();
            Choice_1 = sc.nextInt();
            Divider();
            switch (Choice_1) {
                case 1:
                    do {
                        System.out.println(" 1. Login as customer ");
                        System.out.println(" 2. Login as a employee");
                        System.out.println(" 3. Forgot password");
                        System.out.println(" 4. Main menu");
                        System.out.println(" 5. Exit");

                        Print_Choice();
                        Choice_2 = sc.nextInt();
                        Divider();
                        switch (Choice_2) {
                            case 1:
                                System.out.println("Enter your accounr number or mobile number");
                                System.out.println("Enter your pin");
                                if (true) {
                                    do{
                                        Divider();
                                    System.out.println(" 1. Deposite amount ");
                                    System.out.println(" 2. Withdraw amount");
                                    System.out.println(" 3. View/Detail details ");
                                    System.out.println(" 4. Check balance");
                                    System.out.println(" 5. Change password(pin)");
                                    System.out.println(" 6. Transfer amount ");
                                    System.out.println(" 7. Transaction of account");
                                    System.out.println(" 8. Close account");
                                    System.out.println(" 9. Main menu");
                                    System.out.println(" 10. Exit");
                                    Divider();
                                    }while(Choice_4!=10);
                                } /*else {
                                    System.out.println("Login unsuccesful");
                                }*/
                                break;

                            case 2:
                                break;

                            case 3:
                                break;

                            case 4:
                                break;

                            case 5:
                                break;
                        }

                    } while (Choice_2 != 5);
                    break;
                case 2:
                    do {
                        System.out.println(" 1. Register as customer ");
                        System.out.println(" 2. Register as a employee");
                        System.out.println(" 3. Main menu");
                        System.out.println(" 4. Exit");
                        Print_Choice();
                        Choice_3 = sc.nextInt();
                        switch (Choice_3) {
                            case 1:
                                System.out.println("Enter account number : ");
                                System.out.println("Enter account pin (Default 0000) : ");
                                break;

                            case 2:
                                System.out.println("Enter Employee id : ");
                                System.out.println("Enter Employee pin (Default 0000) : ");
                                break;

                            case 3:
                                break;

                            case 4:
                                break;

                        }
                    } while (Choice_3 != 4);
                    break;
                case 3:
                    System.out.println(" Great to have you here ");
                    System.out.println("Enter account number : ");
                    System.out.println("Enter amount : ");

                    break;
                case 4:
                    customer create_account=new customer();
                    System.out.println("It is pleasure to have you here ...");
                    System.out.println("Enter your name " + create_account.Account_no);
                   // create_account.Customer_Name=InputStreamReader.nextLine();
                    // #input

                    System.out.println("****NOTE****");
                    System.out.println("Your mobile number is your account number");
                    System.out.println("Enter your Mobile number ");
                    //create_account.Account_no=sc.nextLong();

                    // #input

                    System.out.println("Please enter OTP(Default:= 0000)");
                    //create_account.pin=sc.nextShort();

                    // #input

                    System.out.println("Please provide your mail");
                    //create_account.Customer_Mail=sc.nextLine();

                    // #input

                    System.out.println("Which kind of account do you want to open?");
                    System.out.println(" 1. Saving account");
                    System.out.println(" 2. Current account");
                    //create_account.Account_type=sc.nextLine();


                    // #input
                    Divider();
                    //create_account.Print_customer_detail();
                    break;
                case 5:
                    System.out.println("Thank you!");
                    System.out.print("Have a nice day");
                    System.out.println("hope you enjoy our service ");
                    break;

                default:
                    System.out.println("Invalid choice");
                    System.exit(0);
                    break;
            }

        } while (Choice_1 != 5);
    }
}