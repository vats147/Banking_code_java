import java.util.*;
import java.lang.*;

 class customer1{
    String[] name=new String[100];
    customer1(String name){
        this.name[0]=name;
    }
    public  void Print_customer_detail(){
        System.out.println("name "+ name[0]);

    }
}
public class x {
    public static void main(String args[]){
            System.out.println("x");
            customer1 cu=new customer1("hello");
          //  cu.Account_no=121;
           // cu.Customer_name="hello";
            cu.Print_customer_detail();
    }
}
