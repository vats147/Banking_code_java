public class customer {
    String Customer_name;
    long Account_no;
    customer(){Customer_name="hrlo";Account_no=542;}

    public  void Print_customer_detail(){
        System.out.println("Account holder name : " + this.Customer_name);
        System.out.println("Account number  : " + Account_no);}
}
